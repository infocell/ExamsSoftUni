var arr = "068 101 076 101 084 101 100 042 067 111 068 101 042 073 115 042 068 101 066 117 071 071 101 068 042 067 111 068 101".split(" ");

for (var i = 0; i < arr.length; i++){
	console.log('Reply from 95.101.195.91: bytes=32 time=' + arr[i] + 'ms TTL=49');
}